// Public readiness probe only. Never return API keys or private account data.
exports.handler = async () => ({
  statusCode: 200,
  headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'Access-Control-Allow-Origin': 'same-origin' },
  body: JSON.stringify({service:'mellow-sales-status',version:1,server:true,authentication:false,payments:false,entitlements:false,readyForSales:false})
});
